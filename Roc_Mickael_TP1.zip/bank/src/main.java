import java.util.ArrayList;
import java.util.Scanner;

public class main {
	
	ArrayList<Account> listsAccount = new ArrayList<Account>();
	ArrayList<transaction> listsTransaction = new ArrayList<transaction>();
	
	static Scanner sc = new Scanner(System.in);
	int idAccount = 0;
	int idCustomers;
	String name;
	String date;
	double balanceAccount;
	double rateAccount;
	double depositAccount;
	double withdrawAccount;
	
	// creer un Compte
		public void addAccount() {
			System.out.println("******^^------^^******");
			do{
				for (int i = 0; i < listsAccount.size(); i++) {
					if (idAccount == i){
						idAccount = idAccount + 001; 
					}
				}
			}while(idAccount <000);
			
			do{
			System.out.println("Entrer le numero du client : ");
			idCustomers = sc.nextInt();
			}while(idCustomers < 000);
			sc.nextLine();
			System.out.println("Entrer le nom du client: ");
			name = sc.nextLine();
			System.out.println("Entrer le montant du Compte : ");
			balanceAccount = sc.nextDouble();
			System.out.println("Entrer le taux d'int�r�t : ");
			rateAccount = sc.nextDouble();
			sc.nextLine();
			System.out.println("Entrer la date : ");
			date = sc.nextLine();
			transaction transac = new transaction();
			
			transac.setDate_Transaction(date);
			transac.setdeposit(depositAccount);
			transac.setwithdraw(withdrawAccount);
			transac.setamount(balanceAccount);
			Account account = new Account(idAccount, idCustomers, name, balanceAccount, rateAccount);
			listsAccount.add(account);

			System.out.println("******^^------^^******");
		}
		
		
		// d�p�t sur un compte
				public void depositAccount() {
					System.out.println("******^^------^^******");
					System.out.println("Entrer le num�ro de compte : ");
					int nuAccount;
					nuAccount = sc.nextInt();
					System.out.println("******^^------^^******");
					System.out.println("Le balance du compte " + "(" + nuAccount + "): ");
					for (int j = 0; j < listsAccount.size(); j++) {
						if(nuAccount == listsAccount.get(j).getnu_Account()) {
							System.out.println(listsAccount.get(j).getbalance());
							System.out.println("Entrer le montant du deposit: ");
							balanceAccount = sc.nextDouble();
							listsAccount.get(j).setbalance(balanceAccount + listsAccount.get(j).getbalance());
						}
					}
					System.out.println("******^^------^^******");
				}
					
					
				
				
				// retrait sur un compte
						public void withdrawAccount() {
							System.out.println("=====================================");
							System.out.println("Entrer le num�ro de compte : ");
							int nuAccount;
							nuAccount = sc.nextInt();
							System.out.println("******^^------^^******");
							System.out.println("Le balance du compte " + "(" + nuAccount + "): ");
							for (int j = 0; j < listsAccount.size(); j++) {
								if(nuAccount == listsAccount.get(j).getnu_Account()) {
									System.out.println(listsAccount.get(j).getbalance());
									System.out.println("Entrer le montant du retait: ");
									balanceAccount = sc.nextDouble();
									listsAccount.get(j).setbalance(listsAccount.get(j).getbalance() - balanceAccount);
								}
								
							}
							System.out.println("******^^------^^******");
						}
						
						
						// calcul de l'int�r�t
						public void benefitAccount() {
							System.out.println("******^^------^^******");
							for (int i = 0; i < listsAccount.size(); i++) {
								System.out.println(listsAccount.get(i).toString());
								listsAccount.get(i).setbalance((listsAccount.get(i).getbalance() * listsAccount.get(i).getrate()) + listsAccount.get(i).getbalance());
								System.out.println("******^^------^^******");
							}
							for (int i = 0; i < listsAccount.size(); i++) {
								System.out.println(listsAccount.get(i).toString());
								System.out.println("******^^------^^******");
							}
						}
		
		//Consulter la balance d'un compte
		public void search(){
			System.out.println("Entrer le num�ro du compte : ");
			int nuAccount;
			nuAccount = sc.nextInt();
			System.out.println("******^^------^^******");
			System.out.println("Le balance du compte " + "(" + nuAccount + "): ");
			for (int j = 0; j < listsAccount.size(); j++) {
				if(nuAccount == listsAccount.get(j).getnu_Account()) {
					System.out.println(listsAccount.get(j).getbalance());
				}
			}
			System.out.println("******^^------^^******");
		}
		
		// Lister les listes des compte
		public void showAllAccount() {

			for (int i = 0; i < listsAccount.size(); i++) {
				System.out.println(listsAccount.get(i).toString());
				System.out.println("******^^------^^******");
			}
		}
		
		
		//Checher les comptes d'un client
		public void searchAccount(){
			System.out.println("Entrer le num�ro d�identification du client a recherche : ");
			int nuCustomer;
			nuCustomer = sc.nextInt();
			System.out.println("******^^------^^******");
			System.out.println("Les comptes du client " + "(" + nuCustomer + "): ");
			for (int j = 0; j < listsAccount.size(); j++) {
				if(nuCustomer == listsAccount.get(j).getnu_Account()) {
					System.out.println(listsAccount.get(j).toString());
				}
			}
			System.out.println("******^^------^^******");
		}
		


		public void launch() {
			int choice;
			do {
				System.out.println("===**=== Bank ===**===");
				System.out.println("1. Creer un compte.");
				System.out.println("2. d�p�t sur un compte");
				System.out.println("3. retrait sur un compte");
				System.out.println("4. Consulter le balance d'un compte");
				System.out.println("5. Calculer l�int�r�t pour tous les comptes et mettre � jours leur balance");
				System.out.println("6. Rapport des liste de comptes");
				System.out.println("7. Checher les comptes d'un client");
				
				choice = sc.nextInt();
				operation(choice);

			} while (choice != 8);
		}

		public void operation(int key) {
			switch (key) {
			case 1:
				System.out.println("Creer un compte : ");
				addAccount();
				break;
			case 2:
				System.out.println("d�p�t sur un compte : ");
				depositAccount();
				break;
			case 3:
				System.out.println("retrait sur un compte : ");
				withdrawAccount();
				break;
			case 4:
				System.out.println("Consulter le balance d'un compte :");
				search();
				break;
			case 5:
				System.out.println("Calculer l�int�r�t pour tous les comptes et mettre � jours leur balance :");
				//addTache();
				break;
			case 6:
				System.out.println("Rapport des liste de comptes :");
				showAllAccount();
				break;
			case 7:
				System.out.println("Checher les comptes d'un client :");
				searchAccount();
				break;
			default: 
				System.out.println("Erreur de saisi");
				break;
			}
		}	
		

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		main myAccount = new main();
		myAccount.launch();
	}

}
