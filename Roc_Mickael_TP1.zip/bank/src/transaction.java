public class transaction {
	private String date_Transaction;
	private double deposit;
	private double withdraw;
	private double amount;
	
	// constructeurs
	public transaction() {
		
	}

	public transaction(String date_Transaction, double deposit, double withdraw, double amount) {
		this.date_Transaction = date_Transaction;
		this.amount = amount;
		this.deposit = deposit;
		this.withdraw = withdraw;
	}

	/**
	 * @return the date_Transaction
	 */
	public String getDate_Transaction() {
		return date_Transaction;
	}

	/**
	 * @param date_Transaction the date_Transaction to set
	 */
	public void setDate_Transaction(String date_Transaction) {
		this.date_Transaction = date_Transaction;
	}

	/**
	 * @return the deposit
	 */
	public double getdeposit() {
		return deposit;
	}

	/**
	 * @param deposit the deposit to set
	 */
	public void setdeposit(double deposit) {
		this.deposit = deposit;
	}

	/**
	 * @return the withdraw
	 */
	public double getwithdraw() {
		return withdraw;
	}

	/**
	 * @param withdraw the withdraw to set
	 */
	public void setwithdraw(double withdraw) {
		this.withdraw = withdraw;
	}

	/**
	 * @return the amount
	 */
	public double getamount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setamount(double amount) {
		this.amount = amount;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Date Transaction="
				+ date_Transaction + ", deposit=" + deposit
				+ ", withdraw=" + withdraw + ", amount=" + amount
				+ "]";
	}
	

	
}
