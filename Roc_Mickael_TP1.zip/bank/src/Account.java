
public class Account {
	private int nu_Account;
	private int nu_Customers;
	private String customer_Name;
	private double balance;
	private double rate;
	transaction Transaction;
	
	// constructeurs
	public Account() {
		
	}

	public Account(int nu_Account, int nu_Customers, String customer_Name, double balance, double rate) {
		this.nu_Customers = nu_Customers;
		this.nu_Account = nu_Account;
		this.customer_Name = customer_Name;
		this.balance = balance;
		this.rate = rate;
	}
	
	public int getnu_Account() {
		return nu_Account;
	}
	public void setnu_Account(int nu_Account) {
		this.nu_Account = nu_Account;
	}
	public int getnu_Customers() {
		return nu_Customers;
	}
	public void setnu_Customers(int nu_Customers) {
		this.nu_Customers = nu_Customers;
	}
	public String getcustomer_Name() {
		return customer_Name;
	}
	public void setcustomer_Name(String customer_Name) {
		this.customer_Name = customer_Name;
	}
	public double getbalance() {
		return balance;
	}
	public void setbalance(double balance) {
		this.balance = balance;
	}
	public double getrate() {
		return rate;
	}
	public void setrate(double rate) {
		this.rate = rate;
	}
	
	/**
	 * @return the transaction
	 */
	public transaction getTransaction() {
		return Transaction;
	}

	/**
	 * @param transaction the transaction to set
	 */
	public void setTransaction(transaction transaction) {
		Transaction = transaction;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Account [Nu Account =" + nu_Account + ", Nu Customers =" + nu_Customers
				+ ", Customer Name =" + customer_Name + ", balance =" + balance + ", rate ="
				+ rate + ", Transaction =" + Transaction + "]";
	}


	
	
}
